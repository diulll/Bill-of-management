<?php $__env->startSection('content'); ?>
<div class="mb-6">
    <a href="<?php echo e(route('ingredients.index')); ?>" class="text-sm font-medium text-slate-500 hover:text-slate-700 flex items-center gap-1 w-fit transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
        Kembali ke Daftar Bahan Baku
    </a>
</div>

<div class="max-w-2xl bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
    <div class="px-6 py-4 border-b border-slate-200 bg-slate-50">
        <h2 class="text-lg font-semibold text-slate-800">Tambah Bahan Baku Baru</h2>
    </div>

    <form action="<?php echo e(route('ingredients.store')); ?>" method="POST" class="p-6">
        <?php echo csrf_field(); ?>

        <div class="space-y-6">
            <div>
                <label for="name" class="block text-sm font-medium text-slate-700 mb-1">Nama Bahan Baku <span class="text-red-500">*</span></label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" class="w-full rounded-md border-slate-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm px-4 py-2 border outline-none transition" required placeholder="Contoh: Susu Kental Manis (SKM), UHT, Es Batu, dll">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="unit" class="block text-sm font-medium text-slate-700 mb-1">Satuan Dasar <span class="text-red-500">*</span></label>
                <div class="relative">
                    <select name="unit" id="unit" class="w-full rounded-md border-slate-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm px-4 py-2 border outline-none appearance-none transition bg-white" required>
                        <option value="" disabled selected>Pilih Satuan...</option>
                        <option value="gram" <?php echo e(old('unit') == 'gram' ? 'selected' : ''); ?>>Gram (g) — untuk benda padat/bubuk</option>
                        <option value="ml" <?php echo e(old('unit') == 'ml' ? 'selected' : ''); ?>>Mililiter (ml) — untuk benda cair</option>
                        <option value="pcs" <?php echo e(old('unit') == 'pcs' ? 'selected' : ''); ?>>Pieces (pcs) — satuan utuh</option>
                        <option value="slice" <?php echo e(old('unit') == 'slice' ? 'selected' : ''); ?>>Lbr</option>
                    </select>
                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-500">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                    </div>
                </div>
                <p class="mt-2 text-sm text-slate-500 flex items-start gap-1.5">
                    <svg class="w-4 h-4 mt-0.5 flex-shrink-0 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <span><strong>Tips:</strong> Gunakan satuan paling kecil agar perhitungan resep lebih fleksibel (contoh: gunakan 'gram' bukan 'kg').</span>
                </p>
                <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="mt-8 flex justify-end gap-3 pt-6 border-t border-slate-100">
            <a href="<?php echo e(route('ingredients.index')); ?>" class="inline-flex justify-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition">
                Batal
            </a>
            <button type="submit" class="inline-flex justify-center rounded-lg border border-transparent bg-primary px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 transition">
                Simpan Bahan Baku
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BOM\resources\views/ingredients/create.blade.php ENDPATH**/ ?>