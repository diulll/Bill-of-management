<?php $__env->startSection('content'); ?>
<div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
    <div>
        <h1 class="page-heading">Master Data Bahan Baku</h1>
        <p class="text-muted mt-1 text-body-sm">Kelola data bahan baku dasar untuk resep menu.</p>
    </div>
    <div>
        <a href="<?php echo e(route('ingredients.create')); ?>" class="btn-primary btn-sm w-full sm:w-auto">
            <i class="mdi mdi-plus text-lg"></i>
            Tambah Bahan Baru
        </a>
    </div>
</div>

<div class="card">
    <div class="overflow-x-auto">
        <table class="table-airbnb">
            <thead>
                <tr>
                    <th>Nama Bahan</th>
                    <th>Satuan Dasar</th>
                    <th class="text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="font-medium text-ink"><?php echo e($ingredient->name); ?></td>
                    <td><span class="badge-airbnb bg-surface-strong text-ink"><?php echo e($ingredient->unit); ?></span></td>
                    <td class="text-right">
                        <div class="flex items-center justify-end gap-3">
                            <a href="<?php echo e(route('ingredients.edit', $ingredient)); ?>" class="text-ink hover:text-muted font-medium transition flex items-center gap-1 text-body-sm">
                                <i class="mdi mdi-pencil text-lg"></i>
                                Edit
                            </a>
                            <form action="<?php echo e(route('ingredients.destroy', $ingredient)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Apakah Anda yakin ingin menghapus bahan ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-error-text hover:text-red-700 font-medium transition flex items-center gap-1 text-body-sm">
                                    <i class="mdi mdi-delete text-lg"></i>
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3">
                        <div class="empty-state">
                            <i class="mdi mdi-cube-outline empty-state-icon"></i>
                            <p class="empty-state-title">Belum ada data bahan baku.</p>
                            <p class="empty-state-text">Silakan tambah bahan baru terlebih dahulu.</p>
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php if($ingredients->hasPages()): ?>
    <div class="px-6 py-4 border-t border-hairline">
        <?php echo e($ingredients->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BOM\resources\views/ingredients/index.blade.php ENDPATH**/ ?>