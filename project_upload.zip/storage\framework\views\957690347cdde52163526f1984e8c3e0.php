<?php $__env->startSection('content'); ?>
<div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
    <div>
        <h1 class="text-2xl font-bold text-slate-800">Rekap Hitung Cepat</h1>
        <p class="text-slate-500 mt-1">Riwayat kalkulasi bahan baku yang telah disimpan dari Hitung Cepat.</p>
    </div>
    
    <div class="flex gap-2">
        <!-- Filter Tanggal -->
        <div class="bg-white p-1 rounded-lg border border-slate-200 shadow-sm inline-flex">
            <form action="<?php echo e(route('calculator-logs.index')); ?>" method="GET" class="flex items-center gap-2">
                <input type="date" name="date" value="<?php echo e($dateFilter ?? ''); ?>" class="text-sm border-0 focus:ring-0 px-3 py-1.5 bg-transparent cursor-pointer font-medium text-slate-700 outline-none">
                <button type="submit" class="bg-primary text-white p-1.5 rounded-md hover:bg-primary-dark transition">
                    <i class="mdi mdi-magnify text-lg"></i>
                </button>
                <?php if($dateFilter): ?>
                <a href="<?php echo e(route('calculator-logs.index')); ?>" class="text-xs text-slate-400 hover:text-red-500 transition px-1" title="Hapus filter">&times;</a>
                <?php endif; ?>
            </form>
        </div>
        <a href="<?php echo e(route('calculator.index')); ?>" class="inline-flex items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white text-sm px-4 py-2 rounded-lg transition-all duration-150 font-medium shadow-sm active:scale-95 focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2">
            <i class="mdi mdi-plus text-lg"></i>
            Hitung Baru
        </a>
    </div>
</div>

<?php if($logs->isEmpty()): ?>
<div class="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
    <i class="mdi mdi-file-document-outline text-6xl text-slate-300 mx-auto mb-4"></i>
    <h3 class="text-lg font-semibold text-slate-600 mb-1">Belum Ada Rekap</h3>
    <p class="text-sm text-slate-400 mb-4">Mulai hitung bahan di halaman Hitung Cepat, lalu klik Simpan.</p>
    <a href="<?php echo e(route('calculator.index')); ?>" class="inline-flex items-center gap-1.5 bg-primary hover:bg-primary-dark text-white text-sm px-5 py-2.5 rounded-lg transition font-medium">
        Mulai Hitung
        <i class="mdi mdi-arrow-right text-lg"></i>
    </a>
</div>
<?php else: ?>

<div class="space-y-8">
    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $dayLogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
        <!-- Tanggal Header -->
        <div class="flex items-center gap-3 mb-4">
            <div class="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <i class="mdi mdi-calendar text-xl text-primary"></i>
            </div>
            <div>
                <h2 class="text-lg font-bold text-slate-800"><?php echo e(\Carbon\Carbon::parse($date)->translatedFormat('l, d F Y')); ?></h2>
                <p class="text-xs text-slate-400"><?php echo e($dayLogs->count()); ?> rekap</p>
            </div>
        </div>

        <!-- List Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $dayLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('calculator-logs.show', $log)); ?>" class="block group">
                <div class="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-200 overflow-hidden">
                    <!-- Card Header -->
                    <div class="px-5 py-4 border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white">
                        <div class="flex items-start justify-between">
                            <div>
                                <h3 class="font-bold text-slate-800 group-hover:text-primary transition"><?php echo e($log->name); ?></h3>
                                <span class="inline-flex items-center gap-1 text-xs font-medium text-primary bg-primary/10 px-2 py-0.5 rounded-full mt-1">
                                    <i class="mdi mdi-clock-outline text-xs"></i>
                                    <?php echo e($log->shift); ?>

                                </span>
                            </div>
                            <span class="text-xs text-slate-400"><?php echo e($log->created_at->format('H:i')); ?></span>
                        </div>
                    </div>

                    <!-- Card Body: Preview bahan -->
                    <div class="px-5 py-3">
                        <p class="text-xs text-slate-400 font-medium uppercase tracking-wider mb-2">Menu Dihitung</p>
                        <div class="flex flex-wrap gap-1 mb-3">
                            <?php $__currentLoopData = array_slice($log->menus_data, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded"><?php echo e($menu['qty']); ?>x <?php echo e($menu['name']); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($log->menus_data) > 3): ?>
                                <span class="text-xs text-slate-400">+<?php echo e(count($log->menus_data) - 3); ?> lainnya</span>
                            <?php endif; ?>
                        </div>

                        <p class="text-xs text-slate-400 font-medium uppercase tracking-wider mb-1">Bahan Terpakai</p>
                        <p class="text-sm font-semibold text-emerald-600"><?php echo e(count($log->ingredients_data)); ?> jenis bahan</p>
                    </div>

                    <!-- Card Footer -->
                    <div class="px-5 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                        <span class="text-xs text-slate-400">Klik untuk detail</span>
                        <i class="mdi mdi-chevron-right text-lg text-slate-300 group-hover:text-primary group-hover:translate-x-0.5 transition-all"></i>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\BOM\resources\views/calculator-logs/index.blade.php ENDPATH**/ ?>